/* tracker.js — runs inside the extension iframe (chrome-extension:// origin).
 * Camera -> MediaPipe Hands -> gesture -> postMessage to content.js.
 * Because the iframe is a separate extension frame, the heavy hand tracking does not
 * share the page's main thread, so the game itself can't make the tracking lag (and vice versa). */
(() => {
  'use strict';

  const COMPLEXITY = new URLSearchParams(location.search).get('c') === '1' ? 1 : 0; // 0 = fast, 1 = accurate
  const $ = (id) => document.getElementById(id);
  const video = $('cam'), overlay = $('ov'), msgEl = $('msg'), modeEl = $('mode'), perfEl = $('perf');
  const octx = overlay.getContext('2d');

  const post = (m) => parent.postMessage({ gdx: 1, ...m }, '*');

  let cfg = { swapHands: true };
  let running = false, stream = null, hands = null;
  const debouncer = new GestureLogic.Debouncer(2);
  const yFilter = new GestureLogic.OneEuro();
  let state = { mode: 'idle', steer: 0 };
  let prevY = null;
  let infMs = 0, frames = 0, lastPerf = performance.now();

  window.addEventListener('message', (e) => {
    if (e.source !== parent || !e.data || e.data.gdx !== 1) return;
    if (e.data.type === 'config') cfg = { ...cfg, ...e.data.cfg };
  });
  window.addEventListener('pagehide', stop);

  function showMsg(text, isError) {
    msgEl.textContent = text;
    msgEl.className = isError ? 'error' : '';
    post({ type: isError ? 'error' : 'status', text });
  }
  const hideMsg = () => { msgEl.className = 'hidden'; };

  function setMode(s) {
    state = s;
    modeEl.className = s.mode === 'idle' ? '' : s.mode;
    modeEl.textContent = s.mode === 'scroll' ? 'SCROLL' : s.steer < 0 ? '◀ LEFT' : s.steer > 0 ? 'RIGHT ▶' : 'READY';
  }

  async function start() {
    showMsg('Starting camera…');
    try {
      // Small frames are plenty: the model works on ~256 px images anyway, so more pixels only add delay.
      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 320 }, height: { ideal: 240 }, frameRate: { ideal: 30, max: 30 }, facingMode: 'user' },
        audio: false,
      });
    } catch (err) {
      const name = err && err.name;
      showMsg(
        name === 'NotAllowedError' ? 'Camera blocked. Allow it from the camera icon in the address bar, then press Start again.' :
        name === 'NotFoundError' ? 'No camera found.' :
        name === 'NotReadableError' ? 'Camera is busy (another app or tab is using it).' :
        'Camera error: ' + (err && err.message), true);
      return;
    }
    video.srcObject = stream;
    await video.play();
    overlay.width = video.videoWidth || 320;
    overlay.height = video.videoHeight || 240;

    showMsg('Loading hand model…');
    try {
      hands = new Hands({ locateFile: (f) => chrome.runtime.getURL('mediapipe/' + f) });
      hands.setOptions({
        maxNumHands: 2,
        modelComplexity: COMPLEXITY,
        minDetectionConfidence: 0.6,
        minTrackingConfidence: 0.5,
        selfieMode: false,
      });
      hands.onResults(onResults);
      await hands.initialize();
    } catch (err) {
      showMsg('Could not load the hand model: ' + (err && err.message), true);
      return;
    }

    hideMsg();
    post({ type: 'ready' });
    running = true;
    step();
  }

  function stop() {
    running = false;
    if (stream) stream.getTracks().forEach((t) => t.stop());
    stream = null;
    if (hands) { try { hands.close(); } catch (_) { /* ignore */ } hands = null; }
  }

  // One inference per NEW camera frame. The next frame is requested only after the current one
  // is finished, so work never piles up (piled-up work is what makes gestures feel "delayed").
  let lastTime = -1;
  async function step() {
    if (!running) return;
    if (video.currentTime !== lastTime) {
      lastTime = video.currentTime;
      const t0 = performance.now();
      try {
        await hands.send({ image: video });
      } catch (err) {
        running = false;
        showMsg('Tracking stopped: ' + (err && err.message), true);
        return;
      }
      infMs = infMs ? infMs * 0.85 + (performance.now() - t0) * 0.15 : performance.now() - t0;
    }
    if (video.requestVideoFrameCallback) video.requestVideoFrameCallback(step);
    else requestAnimationFrame(step);
  }

  function onResults(res) {
    const lm = res.multiHandLandmarks || [];
    const labels = (res.multiHandedness || []).map((h) => h.label);
    drawDots(lm);

    const r = GestureLogic.classifyFrame(lm, labels, cfg.swapHands);
    const changed = debouncer.update(r.mode, r.steer);
    if (changed) { setMode(changed); post({ type: 'state', mode: changed.mode, steer: changed.steer }); }

    // Scrolling = how far the fingertip moved since the last frame (smoothed, small dead zone).
    if (state.mode === 'scroll' && r.mode === 'scroll' && r.pointer) {
      const y = yFilter.filter(r.pointer.y, performance.now());
      if (prevY !== null) {
        const dy = y - prevY;
        if (Math.abs(dy) > 0.002) post({ type: 'scroll', dy });
      }
      prevY = y;
    } else {
      prevY = null; yFilter.reset();
    }

    frames++;
    const now = performance.now();
    if (now - lastPerf > 500) {
      perfEl.textContent = Math.round(infMs) + ' ms · ' + Math.round(frames * 1000 / (now - lastPerf)) + ' fps';
      frames = 0; lastPerf = now;
    }
  }

  function drawDots(lm) {
    octx.clearRect(0, 0, overlay.width, overlay.height);
    octx.fillStyle = '#22d3ee';
    for (const hand of lm) {
      for (const p of hand) {
        octx.beginPath();
        octx.arc(p.x * overlay.width, p.y * overlay.height, 3, 0, 6.2832);
        octx.fill();
      }
    }
  }

  post({ type: 'hello' }); // content.js answers with the current settings
  start();
})();
