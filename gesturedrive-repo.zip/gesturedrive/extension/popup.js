(() => {
  'use strict';
  const DEFAULTS = { gain: 3, invert: false, swapHands: true, sendKeys: true, accuracy: 0 };
  const $ = (id) => document.getElementById(id);
  let tabId = null, running = false;

  async function ask(msg) {
    try { return await chrome.tabs.sendMessage(tabId, msg); } catch (_) { return null; }
  }

  function render(text, isError) {
    $('toggle').textContent = running ? 'Stop on this tab' : 'Start on this tab';
    $('toggle').classList.toggle('stop', running);
    $('status').textContent = text || (running ? 'Running — see the preview in the page corner.' : 'Stopped');
    $('status').classList.toggle('error', !!isError);
  }

  async function refresh() {
    const st = tabId ? await ask({ type: 'status' }) : null;
    running = !!(st && st.running);
    render(running ? st.text : '');
  }

  async function save() {
    const settings = {
      gain: Number($('gain').value),
      invert: $('invert').checked,
      swapHands: $('swapHands').checked,
      sendKeys: $('sendKeys').checked,
      accuracy: Number($('accuracy').value),
    };
    $('gainOut').textContent = settings.gain;
    await chrome.storage.local.set({ settings });
  }

  async function toggle() {
    if (!tabId) return;
    if (running) {
      await ask({ type: 'stop' });
      running = false;
      render();
      return;
    }
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    } catch (_) {
      render('This page can’t be controlled (browser pages are blocked). Open your game tab first.', true);
      return;
    }
    await ask({ type: 'start' });
    window.close(); // closes the popup so the camera permission prompt is visible
  }

  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab && tab.id;

    const { settings } = await chrome.storage.local.get('settings');
    const s = { ...DEFAULTS, ...(settings || {}) };
    $('gain').value = s.gain;
    $('gainOut').textContent = s.gain;
    $('invert').checked = s.invert;
    $('swapHands').checked = s.swapHands;
    $('sendKeys').checked = s.sendKeys;
    $('accuracy').value = String(s.accuracy);

    ['gain', 'invert', 'swapHands', 'sendKeys', 'accuracy'].forEach((id) => $(id).addEventListener('input', save));
    $('toggle').addEventListener('click', toggle);
    refresh();
  }

  init();
})();
