/* gesture-logic.js — pure gesture classification (no DOM, no camera).
 * Loaded by tracker.html in the browser, and by test.js in Node. */
(function (root) {
  'use strict';

  // MediaPipe hand landmark ids
  const WRIST = 0, THUMB_TIP = 4, INDEX_MCP = 5, MIDDLE_MCP = 9, INDEX_TIP = 8;
  const FINGERS = { index: [8, 6], middle: [12, 10], ring: [16, 14], pinky: [20, 18] }; // [tip, pip]

  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  // How far the fingertip is from the wrist compared with its middle joint: >1 = straight, <1 = folded.
  const ratio = (l, f) => dist(l[f[0]], l[WRIST]) / (dist(l[f[1]], l[WRIST]) || 1);
  const isExtended = (l, f) => ratio(l, f) > 1.2;
  const isCurled = (l, f) => ratio(l, f) < 1.0;

  /** @returns {'point'|'thumb'|null}  point = index up, rest curled; thumb = fist with thumb out */
  function classifyHand(l) {
    const size = dist(l[WRIST], l[MIDDLE_MCP]) || 1;
    const rest = [FINGERS.middle, FINGERS.ring, FINGERS.pinky];
    if (!rest.every((f) => isCurled(l, f))) return null;
    if (isExtended(l, FINGERS.index)) return 'point';
    if (isCurled(l, FINGERS.index) && dist(l[THUMB_TIP], l[INDEX_MCP]) / size > 0.8) return 'thumb';
    return null;
  }

  /**
   * hands: landmark arrays, labels: MediaPipe handedness ('Left'|'Right') per hand.
   * swapHands: true for raw (un-mirrored) webcam frames, where MediaPipe reports hands swapped.
   * @returns {{mode:'idle'|'scroll'|'steer', steer:-1|0|1, pointer:object|null}}
   */
  function classifyFrame(hands, labels, swapHands) {
    let left = false, right = false, pointer = null;
    hands.forEach((l, i) => {
      const pose = classifyHand(l);
      if (pose === 'point') pointer = l[INDEX_TIP];
      else if (pose === 'thumb') {
        const isLeftHand = (labels[i] === 'Left') !== !!swapHands;
        if (isLeftHand) left = true; else right = true;
      }
    });
    const steer = left === right ? 0 : left ? -1 : 1;
    return { mode: steer !== 0 ? 'steer' : pointer ? 'scroll' : 'idle', steer, pointer };
  }

  /** One-Euro filter: smooth when still, almost no lag when moving fast. */
  class OneEuro {
    constructor(minCutoff = 1.2, beta = 8, dCutoff = 1) {
      this.minCutoff = minCutoff; this.beta = beta; this.dCutoff = dCutoff;
      this.reset();
    }
    reset() { this.x = undefined; this.dx = 0; this.t = 0; }
    _a(cutoff, dt) { const tau = 1 / (2 * Math.PI * cutoff); return 1 / (1 + tau / dt); }
    filter(v, tMs) {
      if (this.x === undefined) { this.x = v; this.t = tMs; return v; }
      const dt = Math.max((tMs - this.t) / 1000, 1e-3); this.t = tMs;
      this.dx += this._a(this.dCutoff, dt) * ((v - this.x) / dt - this.dx);
      this.x += this._a(this.minCutoff + this.beta * Math.abs(this.dx), dt) * (v - this.x);
      return this.x;
    }
  }

  /** A new pose must hold for `frames` consecutive frames before it is accepted (kills flicker). */
  class Debouncer {
    constructor(frames = 2) {
      this.frames = frames;
      this.cur = { mode: 'idle', steer: 0 };
      this.cand = null; this.n = 0;
    }
    /** @returns the new state when it changes, otherwise null */
    update(mode, steer) {
      if (mode === this.cur.mode && steer === this.cur.steer) { this.cand = null; this.n = 0; return null; }
      if (this.cand && this.cand.mode === mode && this.cand.steer === steer) this.n++;
      else { this.cand = { mode, steer }; this.n = 1; }
      if (this.n >= this.frames) { this.cur = this.cand; this.cand = null; this.n = 0; return this.cur; }
      return null;
    }
  }

  const api = { classifyHand, classifyFrame, OneEuro, Debouncer };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.GestureLogic = api;
})(typeof self !== 'undefined' ? self : this);
