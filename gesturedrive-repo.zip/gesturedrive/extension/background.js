// background.js — only handles the Alt+Shift+G shortcut (start/stop on the current tab).
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-gestures') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  try {
    // content.js ignores a second injection, so this is safe to repeat.
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await chrome.tabs.sendMessage(tab.id, { type: 'toggle' });
  } catch (_) {
    // browser-internal pages (edge://, the Web Store) can't be scripted
  }
});
