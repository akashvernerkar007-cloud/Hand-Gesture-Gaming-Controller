/* content.js — injected into the page on demand (popup Start button or Alt+Shift+G).
 * Creates the tracker iframe, then turns its messages into page scrolling and arrow-key events. */
(() => {
  'use strict';
  if (window.__gestureDrive) return; // already injected on this page
  window.__gestureDrive = true;

  const EXT_ORIGIN = new URL(chrome.runtime.getURL('')).origin;
  const DEFAULTS = { gain: 3, invert: false, swapHands: true, sendKeys: true, accuracy: 0 };
  let settings = { ...DEFAULTS };
  let frame = null, starting = false, statusText = 'Stopped';

  // ---------- start / stop ----------
  async function start() {
    if (frame || starting) return;
    starting = true;
    statusText = 'Starting…';
    try {
      const stored = await chrome.storage.local.get('settings');
      settings = { ...DEFAULTS, ...(stored.settings || {}) };
    } catch (_) { /* use defaults */ }

    frame = document.createElement('iframe');
    frame.src = chrome.runtime.getURL('tracker.html') + '?c=' + (settings.accuracy ? 1 : 0);
    frame.allow = 'camera; autoplay';
    frame.setAttribute('tabindex', '-1');
    frame.setAttribute('aria-hidden', 'true');
    frame.setAttribute('title', 'GestureDrive camera preview');
    frame.style.cssText =
      'all:initial;position:fixed;right:12px;bottom:12px;width:176px;height:150px;border:0;' +
      'border-radius:10px;z-index:2147483647;pointer-events:none;' +
      'box-shadow:0 6px 24px rgba(0,0,0,.45);background:#0b1020;';
    document.documentElement.appendChild(frame);
    starting = false;
  }

  function stop() {
    releaseKey();
    if (frame) { frame.remove(); frame = null; }
    statusText = 'Stopped';
  }

  // ---------- messages from popup / background ----------
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg.type === 'start') start();
    else if (msg.type === 'stop') stop();
    else if (msg.type === 'toggle') (frame || starting ? stop() : start());
    reply({ running: !!(frame || starting), text: statusText });
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (!changes.settings) return;
    settings = { ...DEFAULTS, ...(changes.settings.newValue || {}) };
    sendConfig();
    if (!settings.sendKeys) releaseKey();
  });

  // ---------- messages from the tracker iframe ----------
  window.addEventListener('message', (e) => {
    if (!frame || e.source !== frame.contentWindow || e.origin !== EXT_ORIGIN) return; // ignore the page itself
    const m = e.data;
    if (!m || m.gdx !== 1) return;
    switch (m.type) {
      case 'hello': sendConfig(); break;
      case 'status': statusText = m.text; break;
      case 'ready': statusText = 'Running'; break;
      case 'error': statusText = m.text; break;
      case 'state': applySteer(m.steer); break;
      case 'scroll': scrollPage(m.dy); break;
    }
  });

  function sendConfig() {
    if (frame && frame.contentWindow) {
      frame.contentWindow.postMessage({ gdx: 1, type: 'config', cfg: { swapHands: settings.swapHands } }, EXT_ORIGIN);
    }
  }

  // ---------- scrolling ----------
  let scroller = null, scrollerAt = 0;

  function canScroll(el) {
    const cs = getComputedStyle(el);
    return /(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 4;
  }

  // The page itself if it scrolls; otherwise the scrollable container in the middle of the screen
  // (many Angular layouts scroll an inner <div>, where window.scrollBy would do nothing).
  function findScroller() {
    const now = performance.now();
    if (scroller && scroller.isConnected && now - scrollerAt < 600) return scroller;
    const root = document.scrollingElement || document.documentElement;
    let target = root.scrollHeight > root.clientHeight + 4 ? root : null;
    if (!target) {
      let el = document.elementFromPoint(window.innerWidth / 2, window.innerHeight / 2);
      while (el && el !== document.body && el !== document.documentElement) {
        if (canScroll(el)) { target = el; break; }
        el = el.parentElement;
      }
    }
    scroller = target || root;
    scrollerAt = now;
    return scroller;
  }

  function scrollPage(dy) {
    // dy = fingertip movement as a fraction of the camera frame (down = positive).
    const px = -dy * settings.gain * window.innerHeight * (settings.invert ? -1 : 1);
    // behavior 'instant' beats `scroll-behavior: smooth` in page CSS, which would add lag.
    findScroller().scrollBy({ top: px, left: 0, behavior: 'instant' });
  }

  // ---------- arrow keys (behaves like a real held keyboard key) ----------
  let held = null, repeatDelay = 0, repeatTimer = 0;

  function fire(type, key, repeat) {
    const code = key === 'ArrowLeft' ? 37 : 39;
    const ev = new KeyboardEvent(type, {
      key, code: key, keyCode: code, which: code, repeat: !!repeat,
      bubbles: true, cancelable: true, composed: true,
    });
    const target = document.activeElement && document.activeElement !== frame ? document.activeElement : document.body;
    target.dispatchEvent(ev);
  }

  function releaseKey() {
    clearTimeout(repeatDelay); clearInterval(repeatTimer);
    if (held) { fire('keyup', held); held = null; }
  }

  function pressKey(key) {
    releaseKey();
    held = key;
    fire('keydown', key, false);
    // same timing as OS key repeat: short pause, then repeats while held
    repeatDelay = setTimeout(() => { repeatTimer = setInterval(() => fire('keydown', key, true), 33); }, 450);
  }

  function applySteer(steer) {
    if (!settings.sendKeys) return;
    if (steer < 0) { if (held !== 'ArrowLeft') pressKey('ArrowLeft'); }
    else if (steer > 0) { if (held !== 'ArrowRight') pressKey('ArrowRight'); }
    else releaseKey();
  }

  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseKey(); });
})();
