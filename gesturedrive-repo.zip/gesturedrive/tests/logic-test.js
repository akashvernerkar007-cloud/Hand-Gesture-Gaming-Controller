const L = require('../extension/gesture-logic.js');
const P = (x, y) => ({ x, y, z: 0 });

// Synthetic upright hand. index: 'ext'|'curl', rest: 'ext'|'curl', thumb: 'out'|'in'
function hand({ index = 'curl', rest = 'curl', thumb = 'in' }) {
  const l = new Array(21).fill(0).map(() => P(0.5, 0.9));
  l[0] = P(0.5, 0.9);                                  // wrist
  const xs = { index: 0.43, middle: 0.5, ring: 0.57, pinky: 0.64 };
  const ids = { index: [5, 6, 7, 8], middle: [9, 10, 11, 12], ring: [13, 14, 15, 16], pinky: [17, 18, 19, 20] };
  for (const f of Object.keys(ids)) {
    const ext = (f === 'index' ? index : rest) === 'ext';
    const [mcp, pip, dip, tip] = ids[f];
    l[mcp] = P(xs[f], 0.64);
    l[pip] = P(xs[f], ext ? 0.50 : 0.58);
    l[dip] = P(xs[f], ext ? 0.41 : 0.66);
    l[tip] = P(xs[f], ext ? 0.33 : 0.72);
  }
  l[1] = P(0.38, 0.84); l[2] = P(0.33, 0.78); l[3] = P(thumb === 'out' ? 0.22 : 0.40, thumb === 'out' ? 0.72 : 0.70);
  l[4] = thumb === 'out' ? P(0.12, 0.68) : P(0.45, 0.66);
  return l;
}

let fails = 0;
const eq = (name, got, want) => {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  if (!ok) fails++;
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok ? '' : `  got=${JSON.stringify(got)} want=${JSON.stringify(want)}`));
};

eq('pointing hand -> point', L.classifyHand(hand({ index: 'ext', rest: 'curl', thumb: 'in' })), 'point');
eq('pointing + thumb out -> point', L.classifyHand(hand({ index: 'ext', rest: 'curl', thumb: 'out' })), 'point');
eq('fist, thumb tucked -> none', L.classifyHand(hand({})), null);
eq('fist + thumb out -> thumb', L.classifyHand(hand({ thumb: 'out' })), 'thumb');
eq('open hand -> none', L.classifyHand(hand({ index: 'ext', rest: 'ext', thumb: 'out' })), null);

const thumbHand = hand({ thumb: 'out' }), point = hand({ index: 'ext' });
// raw webcam frames (swapHands=true): MediaPipe label 'Right' == the user's LEFT hand
eq('left hand thumb (label Right, swap) -> steer -1', L.classifyFrame([thumbHand], ['Right'], true).steer, -1);
eq('right hand thumb (label Left, swap) -> steer +1', L.classifyFrame([thumbHand], ['Left'], true).steer, 1);
eq('no swap: label Left -> steer -1', L.classifyFrame([thumbHand], ['Left'], false).steer, -1);
eq('both thumbs cancel -> steer 0', L.classifyFrame([thumbHand, thumbHand], ['Left', 'Right'], true).steer, 0);
eq('point -> scroll mode', L.classifyFrame([point], ['Left'], true).mode, 'scroll');
eq('steer wins over scroll', L.classifyFrame([point, thumbHand], ['Left', 'Right'], true).mode, 'steer');
eq('no hands -> idle', L.classifyFrame([], [], true).mode, 'idle');

// Debouncer: needs 2 consecutive frames
const d = new L.Debouncer(2);
eq('debounce frame 1 -> no change', d.update('steer', -1), null);
eq('debounce frame 2 -> change', d.update('steer', -1), { mode: 'steer', steer: -1 });
eq('held pose -> no repeat event', d.update('steer', -1), null);
eq('single flicker ignored', d.update('idle', 0), null);
eq('flicker back -> still no event', d.update('steer', -1), null);
d.update('idle', 0);
eq('release after 2 frames', d.update('idle', 0), { mode: 'idle', steer: 0 });

// One-Euro: still hand is steady, fast move tracks closely
const f = new L.OneEuro(); let v;
for (let i = 0; i < 30; i++) v = f.filter(0.5 + (i % 2 ? 0.002 : -0.002), i * 33);
eq('jitter suppressed (|err|<0.0015)', Math.abs(v - 0.5) < 0.0015, true);
const g = new L.OneEuro(); let out;
for (let i = 0; i < 6; i++) out = g.filter(0.2 + i * 0.1, i * 33);
eq('fast move lag < 0.12', 0.7 - out < 0.12, true);

console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
process.exit(fails ? 1 : 0);
